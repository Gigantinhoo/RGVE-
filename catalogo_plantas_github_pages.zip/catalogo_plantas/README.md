# Catálogo de Plantas e Orçamentos

Aplicação estática para publicar no GitHub Pages. O banco e o armazenamento das fotos ficam no Supabase, então cadastrar uma planta não exige baixar ZIP nem republicar o site.

## O que já está implementado
- Login de administrador via Supabase Auth.
- Catálogo único compartilhado por Vale Europeu Plantas e Rony Gigante.
- Cadastro, edição e exclusão de apresentações de plantas.
- Upload de foto direto pelo formulário.
- Campos: nome, nome científico, altura, DAP, preço, disponibilidade e observações.
- Montagem de orçamento com escolha da marca, cliente, validade, quantidade e preço unitário.
- PDF com cabeçalho da marca escolhida e foto, altura, DAP, quantidade, preço e subtotal por item.

## 1. Criar o banco
1. Crie um projeto em https://supabase.com.
2. Abra SQL Editor e execute todo o arquivo `supabase.sql`.
3. Em Authentication > Users, crie o usuário administrador (e outros usuários autorizados, se necessário).
4. Em Project Settings > API, copie Project URL e a chave `anon`/`publishable`.

## 2. Conectar o site
Abra `index.html` e substitua:
- `COLE_A_URL_DO_SEU_PROJETO` por Project URL.
- `COLE_A_CHAVE_ANON_PUBLIC` pela chave anon/public.

A chave anon/public pode ficar no navegador porque o acesso é protegido por Auth e RLS. **Nunca use a chave `service_role` no HTML.**

## 3. Publicar no GitHub Pages
1. Envie `index.html` e `supabase.sql` para a raiz do repositório.
2. No GitHub, entre em Settings > Pages.
3. Em Build and deployment, selecione Deploy from a branch, escolha `main` e `/ (root)`.
4. Salve e aguarde a publicação.

## Observações
- O GitHub Pages hospeda a interface; Supabase guarda dados e imagens. Depois de conectado, novos cadastros aparecem sem novo deploy.
- O PDF é gerado no navegador.
- Esta primeira versão usa um cabeçalho tipográfico para as duas marcas. Para inserir os logotipos oficiais, basta fornecer os arquivos de logo.
- As duas marcas usam o mesmo catálogo e, nesta versão, compartilham o mesmo preço por cadastro. Se os preços forem diferentes por marca, a estrutura pode ser ampliada com preço específico para cada marca.
- A primeira versão não inclui assinatura, envio automático por WhatsApp ou numeração sequencial de propostas.
